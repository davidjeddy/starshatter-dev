Creator:	Otega
Website:	http://home.graffiti.net/otega/
eMail:		Otega@post.com

Name:		Switchblade
Class:		Fighter
Details:	This is another ship I had in idea. It kinda looks like a shivian fighter
in freespace according to someone else.

Release Date:	7-25-2002
Release Version: 1.0
Release Notes: none.

Copyright Stuff: Any textures/3d models that are created by Otega. This ship addon can be distributed in anyway.
As long as you do not rip textures/modify them in anyway. this ship mods are not supported by John DiCamillo in
any way so use it at your own risk.