Creator:	Otega
Website:	http://home.graffiti.net/otega/
eMail:		Otega@post.com

Name:		longbow
Class:		Fighter
Details:	One of the first new ships that was made. Mr_Switch made the textures(one
with the red happy faces on them) and let me use them. Right now ship has 3 alpha cannons
stacked on 2 gunports(6 total) since i cannot get the vulcan cannon to work properly on
them. Mabie if the patch that will let you make new weapons come out, then I'll think about
sending another update version of this ship.

Release Date:	7-25-2002
Release Version: 1.0
Release Notes: none.

Copyright Stuff: There are some textures/3d models that are created by Otega. This ship addon can be distributed in anyway.
As long as you do not rip textures/modify them in anyway if created by the author. this ship mods are not supported by John
DiCamillo in any way so use it at your own risk.