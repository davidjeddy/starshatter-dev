Well this is my first bomber, kinda like the oldshool look to it.. 
Ver. 0.09 alpha 
Need to tweek every thing its to fast right now, turns to quick, and i need to find a way to fix the Tail turret.

