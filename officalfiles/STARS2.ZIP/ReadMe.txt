STARSHATTER(TM) DEMO 2.0
README FILE
Copyright � 2000 John DiCamillo

http://members.home.net/milod
milod@home.com

INTRODUCTION

Thank you for downloading the Starshatter Demo 2.0.  This README
will give you a brief introduction to the game and how to play it.
For detailed gameplay instructions, see the file PLAYER.DOC.

What Is Starshatter?

Starshatter is a new space combat simulation game that is currently
in the middle stages of development.  The game offers a new type of
combat experience in an original science fiction universe.  Unlike
most other games, which limit the player to flying fighters and other
small craft, Starshatter gives you the opportunity to directly command
a wide variety of ships, from agile atmospheric and space-based
fighters to giant cruisers and fleet carriers.  Starshatter aims
to simulate the complete space combat experience -- from planet
surface to interstellar space -- with several dynamic campaigns set
in a persistent simulated universe.

Starshatter is being developed for IBM PC compatibles running Microsoft
Windows 95, Windows 98, Windows NT, or Windows 2000.

Game Features

� Intelligent Combat Scenarios
� Realistic Physics
� 	Newtonian Space Combat (with computer assist)
� 	Hardcore Atmospheric Flight Modeling
� Realistic Sensors and Avionics
� Realistic Space Environments
� Stunning 3D Accelerated Graphics
� Stereo Sound

What Is This Demo All About?

This early demo is being released to solicit feedback from the space 
sim community.  If you've ever wanted to influence a space sim game
design, now's your big chance!  At this stage of development, the
graphics engine and basic gameplay mechanics are complete.  Advanced
AI, the dynamic campaign engine, and multiplayer features are still
being developed.

After you've had a chance to play the game a bit, please tell me what
you think of it!  Any and all comments are welcome -- good and bad
alike.  The main thing I want to know is: did you enjoy the demo? 
And are you interested in playing the full game when it is complete? 
Are there any other features you really want to see?  Send your
comments to milod@home.com.

HARDWARE REQUIREMENTS

Recommended System:
Pentium II 400 MHz (or equivalent)
64 MB system RAM
24 MB available hard disk space
Direct3D compatible 3D accelerator with AGP 2x and 32 MB RAM
DirectX compatible Sound Card
3 or 4 Axis Joystick with 4 buttons and hat switch
Mouse

OPERATING SYSTEM AND DRIVERS

Starshatter is being developed for IBM PC compatibles running Microsoft
Windows 95, Windows 98, Windows NT 4 (SP 3+), or Windows 2000.  It should
also work under Windows ME, but this has not been tested.  Starshatter
uses DirectX to access audio and video hardware.  You must have at least
DirectX version 3.0 installed for the game to run, but DirectX 6.1 or
DirectX 7 is strongly preferred.

Note that 3D accelerated graphics are available under Windows 95,
Windows 98, and Windows 2000 only.  When Starshatter is run under
Windows NT 4, it will use a custom software rendering mode.  The
software rendering mode can also be used if there are any problems
getting Starshatter to work with your 3D hardware.

INSTALLATION

The Starshatter demo is being distributed as a compressed archive (ZIP
file).  To install the demo, create a directory of your choice (e.g.
C:\Games\StarDemo) and unzip the contents of the archive into it.
To play the demo, double click the stars.exe icon in the new directory.

To uninstall the demo, simply delete the directory and all its contents.
The Starshatter demo will not modify the system registry, or any other
directory on your computer.

GAMEPLAY

Full gameplay instructions can be found in the file PLAYER.DOC.
This is a Microsoft Word 6 file that can be read using any recent
version of Microsoft Word, or WordPad.exe.

If at all possible, print out a copy of the Player Manual before
playing the game.

BASIC CONTROLS

This is the minimum set of controls you need to know to control your
ship and play the game:

Pitch Up                   Arrow Down     Joystick Back
Pitch Down                 Arrow Up       Joystick Forward
Yaw (Turn) Left            Arrow Left     Joystick Left
Yaw (Turn) Right           Arrow Right    Joystick Right

Increase Throttle          A
Decrease Throttle          Z
Full Stop (Zero Throttle)  S

Target Ship in Reticle     T
Fire Primary Weapons       F              Joystick Button 1
Fire Secondary Weapons     Space          Joystick Button 2

Exit to Menu               Esc


CONTACT INFORMATION

http://members.home.net/milod
milod@home.com


The Starshatter Universe and all related inidicia
Copyright � 1997-2000 John DiCamillo
All rights reserved.
