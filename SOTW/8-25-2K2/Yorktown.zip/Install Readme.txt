Install the contents of the Mods Folder to your Starshatter game Folder.

ie. C:\Games\Starshatter\Mods

Enjoy!

D M