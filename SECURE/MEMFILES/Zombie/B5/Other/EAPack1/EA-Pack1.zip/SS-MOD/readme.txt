This is the first release of my Earth Alliance Pack.
The weapons and Ships are not finaly ballanced, if you are good at this,
maybe you can help me doing this. Simply Drop me a eMail.
I hope you enjoy this anyway since it allready makes lots of fun :)

Ships included:
		SA-23E - Aurora Starfury 
		SA-26A - Thunderbolt Starfury
		SA-23F - Badger Starfury
		Hyperion Cruiser (Midwinter Class)
		Omega Destroyer
		Nova Dreadnought
		Olympus Corvette

Maps included:	Civil War - Map to show a small battle with some Big ships


Installation:	Simply extract this file into your Starshatter Folder


Note:		As i am bad at making Textures i do NOT take any Credit for the Textures 		these ships use, mostly i used renders of these ships as textures, or 			borrowed them from the Great Wars MOD for Homeworld (Nova, Omega).
		If you think that the Textures i used are your work simply drop me a eMail
		or contact me via ICQ and i will add you credit


Made by:	Zombie
		zombie@tiberium-hl.com
		ICQ# 82507882
