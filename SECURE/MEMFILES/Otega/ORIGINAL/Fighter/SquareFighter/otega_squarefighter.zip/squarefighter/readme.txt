Creator:	Mr. SwitcH
Website:	http://starshatter.cjb.net
eMail:		-

Name:		Square Fighter
Class:		fighter
Details:	tie-fighter rip off.

Release Date:	May 2002
Release Version:1.0.4
Release Notes:	finished but it needs to be tweaks just a few attributes.

Copyright Stuff: absolutly none. besides, the square fighter is a complete spin-off
from a tie fighter. I made it cuz i was board and had no ideas at all. have fun
blowing it away in your missions.

HOW TO INSTAL THIS SHIP INTO THE DIRECTORY???

Create a directory in the "mods" directory in whatever you installed Starshatter in.
like: X:\Starshatter\mods\ and then create a new folder and name it "squarefighter"(watch
it cuz its case sentive!) in the "mods" directory. walla, there you go.