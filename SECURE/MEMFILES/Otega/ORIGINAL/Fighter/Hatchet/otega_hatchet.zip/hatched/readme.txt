Creator:	Otega
Website:	http://home.graffiti.net/otega/
eMail:		Otega@post.com

Name:		Hatchet
Class:		Fighter
Details:	this is my very first ship I ever to be created and put into this game.
this ship is use for starshatter.

Release Date:	5-23-2002
Release Version: 3.0
Release Notes:	partly finished.

Copyright Stuff: (C) 2002 Otega, this ship can be distributed as long as nothing gets
modified in the archive.