Creator:	Otega
Website:	http://home.graffiti.net/otega/
eMail:		Otega@post.com

Name:		Gliger
Class:		Fighter
Details:	Yet another fighter ship aromed with three guns.

Release Date:	7-25-2002
Release Version: 1.0
Release Notes: none.

Copyright Stuff: There are some textures/3d models that are created by Otega. This ship addon can be distributed in anyway.
As long as you do not rip textures/modify them in anyway if created by the author. this ship mods are not supported by John
DiCamillo in any way so use it at your own risk.