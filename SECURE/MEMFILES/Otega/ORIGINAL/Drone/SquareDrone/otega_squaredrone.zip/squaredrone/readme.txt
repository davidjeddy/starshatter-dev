Creator:	Mr. SwitcH
Website:	http://starshatter.cjb.net
eMail:		-

Name:		Squaredrone
Class:		fighter
Details:	Well it's supposed to be a drone, this is the most simpilest ship i
ever created. welll is just a cub model with textures on it, and the gun mount is
on front of it. this is good for people who want to take a short look in to the
.def file and try to add their own ship into the game.

Release Date:	May 2002
Release Version: 1
Release Notes:	none

Copyright Stuff: absolutly none. Feel free to distribute it.

HOW TO INSTAL THIS SHIP INTO THE DIRECTORY???

Create a directory in the "mods" directory in whatever you installed Starshatter in.
like: X:\Starshatter\mods\ and then create a new folder and name it "squaredrone"(watch
it cuz its case sentive!) in the "mods" directory. walla, there you go.