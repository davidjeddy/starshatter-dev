Creator:	Otega
Website:	http://home.graffiti.net/otega/
eMail:		Otega@post.com

Name:		Angel
Class:		Fighter
Details:	Something like a missle playform ship. Large firepower, large armor but not
very menuverable compared to the others. Not ment for atmosphearic flights either.

Release Date:	7-25-2002
Release Version: 1.0
Release Notes: none.

Copyright Stuff: Any textures/3d models that are created by Otega. This ship addon can be distributed in anyway. As long
as you do not rip or modify the textures/3d models in anyway. this ship mods are not supported by John DiCamillo in
any way so use it at your own risk.